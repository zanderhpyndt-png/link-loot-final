
'use client';

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';
import { firebaseConfig } from './config';

let app: FirebaseApp | undefined;
let auth: Auth | undefined;
let db: Firestore | undefined;

/**
 * Safely initializes Firebase services.
 * Prevents crashing if configuration (API Keys) is missing.
 */
export function initializeFirebase() {
  if (typeof window === 'undefined') return { app: null, auth: null, db: null };

  if (getApps().length > 0) {
    app = getApp();
  } else {
    // Only attempt to initialize if we have a valid-looking API key.
    if (firebaseConfig.apiKey && firebaseConfig.apiKey.length > 10) {
      try {
        app = initializeApp(firebaseConfig);
      } catch (e) {
        console.warn("Firebase initialization failed:", e);
      }
    } else {
      console.warn("Firebase API Key is missing or invalid. Check your environment variables.");
    }
  }

  if (app) {
    try {
      auth = getAuth(app);
      db = getFirestore(app);
    } catch (e) {
      console.warn("Error initializing Firebase services:", e);
    }
  }

  return { 
    app: app || null, 
    auth: auth || null, 
    db: db || null 
  };
}

export * from './provider';
export * from './auth/use-user';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
