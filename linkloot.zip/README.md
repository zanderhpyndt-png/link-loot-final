
# 🚀 LinkLoot Deployment Guide

## Step 1: GitHub
1. Create a repo named `link-loot` on GitHub.
2. Click **"uploading an existing file"** on the repo main page.
3. Drag and drop all files from this project into that box and commit.

## Step 2: Firebase App Hosting
1. Go to [console.firebase.google.com](https://console.firebase.google.com).
2. Create a project.
3. Click **Build > App Hosting** in the sidebar.
4. Connect your GitHub and select the `link-loot` repo.

## Step 3: Secret Keys
In the Firebase Console, go to your **App Hosting** dashboard settings and add these **Environment Variables**:

1. `GOOGLE_GENAI_API_KEY`: From [aistudio.google.com](https://aistudio.google.com/app/apikey).
2. `NEXT_PUBLIC_FIREBASE_API_KEY`: From Project Settings.
3. `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`: From Project Settings.
4. `NEXT_PUBLIC_FIREBASE_PROJECT_ID`: From Project Settings.
5. `NEXT_PUBLIC_FIREBASE_APP_ID`: From Project Settings.
