# **App Name**: LinkLoot

## Core Features:

- Product URL Input & Parsing: Users can paste any product URL from various e-commerce sites (Amazon, IKEA, Temu, etc.). The AI tool then extracts and structures key product data including name, images, specifications, category, and initial pricing details from the page.
- AI Product Matching Engine: Leveraging AI embeddings and semantic search, this tool identifies identical or highly similar products across a vast array of online marketplaces, detecting variations like different titles for the same product, white-label duplicates, or identical factory items.
- Real-time Price Comparison Cards: Displays comparison results in a sleek, card-based interface, detailing the product image, store logo, current price, estimated shipping costs, delivery times, review scores, and potential 'savings vs original' from various vendors.
- AI Markup & Scam Detector: An AI tool analyzes product pricing and sourcing data to detect potential dropshipping markups, unusually high prices, or common 'trending markup tactics', providing transparent badges like 'Likely dropshipped' or 'Overpriced by X%' directly on the comparison cards.
- Cheapest/Best Option Highlights: Automatically highlights the most advantageous product comparison result based on user-defined priorities or predefined smart criteria, such as the cheapest overall price, fastest shipping, or best aggregate customer reviews.
- Direct Store Navigation: Provides convenient buttons on each comparison card to directly access the original or the cheaper alternative product page on the respective e-commerce store.
- Dynamic Loading States: Implements animated loading sequences and skeleton cards during product analysis and search, ensuring a perception of speed and a fluid, engaging user experience consistent with the 'insanely fast search feel' goal.

## Style Guidelines:

- Color Scheme: A dark mode aesthetic to embody a premium, modern, and high-tech feel, suitable for a sophisticated shopping intelligence platform.
- Background Color: A very dark, desaturated blue-grey (#202326), chosen for its ability to create depth and a contemporary backdrop, allowing UI elements to pop without being jarring.
- Primary Color: A bright, but still rich, cool blue (#699EF0) that contrasts effectively with the dark background, conveying trust, technology, and clarity, resonating with a sleek modern UI.
- Accent Color: A vibrant turquoise-cyan (#31A0C6) analogous to the primary hue, providing a fresh and dynamic element for interactive components and highlights, ensuring good visual differentiation and energy.
- Font Recommendation: 'Inter' (sans-serif) for all textual content. Its modern, objective, and neutral aesthetic aligns perfectly with a sleek, premium, and data-driven platform, ensuring readability for both headlines and body text.
- Icon Style: Utilize a minimalist, clean, vector-based line icon set that integrates seamlessly with the dark mode and glassmorphism design elements, enhancing the overall sleek and premium aesthetic.
- Layout Principles: A mobile-first, responsive grid system with generous spacing, designed to highlight 'glassmorphism cards' effectively. Emphasizes clear, intuitive presentation of comparison data with a sticky mobile CTA.
- Animation Philosophy: Implement smooth, subtle transitions and microinteractions using Framer Motion. This includes animated loading states, skeleton loaders, and engaging card interactions to provide a fast and addictive user experience.